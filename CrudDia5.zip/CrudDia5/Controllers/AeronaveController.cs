﻿using CrudDia5.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using CrudDia5.Controllers;
using System;


namespace CrudDia5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AeronaveController : ControllerBase
    {
        private DDBBContext _context;

       public 
    }


}
