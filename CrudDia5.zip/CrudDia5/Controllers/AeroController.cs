﻿using CrudDia5.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CrudDia5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AeroController : ControllerBase
    {
        private DDBBContext _context;

        public AeroController(DDBBContext context)
        {
            _context = context;
        }
    }
}
