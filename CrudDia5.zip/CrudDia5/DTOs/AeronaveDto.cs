﻿namespace CrudDia5.DTOs
{
    public class AeronaveDto
    {
        public int ID { get; set; }
        public string Tipo { get; set; }
        public string Modelo { get; set; }
        public int CapacidadCarga { get; set; }
        public int HorasVuelo { get; set; }
        public bool Disponibilidad { get; set; }
    }
}
