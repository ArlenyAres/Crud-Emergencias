﻿using Microsoft.EntityFrameworkCore;

namespace CrudDia5.Models
{
    internal class DDBBContext : DbContext
    {
        public DDBBContext(DbContextOptions<DDBBContext> options) : base(options)
        {
        }

        public DbSet<Aeronave> Aeronaves { get; set; } 

        public DbSet<MisionEmergencia> MisionEmergencias { get; set; }

        public DbSet<Piloto> Pilotos { get; set; }
    }
}